package com.iwandepe.ebuk_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
